const systemName = "hellas";
const systemBasePath = `systems/${systemName}`;
const registerSettings = function () {
    // Register any custom system settings here
    // Register custom Handlebar helpers
    // concatenate some number of strings passed as parameters
    Handlebars.registerHelper('concat', function () {
        let outStr = '';
        for (let arg in arguments) {
            if (typeof arguments[arg] != 'object') {
                outStr += arguments[arg];
            }
        }
        return outStr;
    });
    /**
     * For a str, html escape it, and convert any line breaks into '<br>' tags
     */
    Handlebars.registerHelper('breaklines', function (str) {
        str = Handlebars.Utils.escapeExpression(str);
        str = str.replace(/(\r\n|\n|\r)/gm, '<br>');
        return new Handlebars.SafeString(str);
    });
    /**
     * Given an array of objects, return the first entry where the object's property named 'key' has the value 'value'
     */
    Handlebars.registerHelper('findEntryByKeyValue', function (arr, key, value, options) {
        if (!Array.isArray(arr)) {
            console.log('first param is not an array: ' + arr);
            return null;
        }
        for (let i = 0; i < arr.length; i++) {
            const entry = arr[i];
            if (!entry.hasOwnProperty(key))
                continue;
            if (entry[key] === value)
                return entry;
        }
        return null;
    });
    // if 'elem' is in an array
    Handlebars.registerHelper('ifIn', function (elem, list, options) {
        if (list.indexOf(elem) > -1) {
            return options.fn(this);
        }
        return options.inverse(this);
    });
    // repeat something 'n' times
    Handlebars.registerHelper("repeat", function (times, opts) {
        let out = "";
        let i;
        let data = {};
        if (times && Number.isFinite(times)) {
            for (i = 0; i < times; i++) {
                data.index = i;
                data.num = i + 1;
                data.first = i === 0;
                data.last = i === (times - 1);
                out += opts.fn(this, {
                    data: data
                });
            }
        }
        else {
            out = opts.inverse(this);
        }
        return out;
    });
    Handlebars.registerHelper("setVar", function (varName, varValue, options) {
        options.data.root[varName] = varValue;
    });
    Handlebars.registerHelper('toLowerCase', function (str) {
        return str.toLowerCase();
    });
    Handlebars.registerHelper('numToStr', function (num) {
        if (Number.isFinite(num)) {
            return num.toString(10);
        }
        return "";
    });
    Handlebars.registerHelper("selected", value => value ? "selected" : "");
    Handlebars.registerHelper("disabled", value => value ? "disabled" : "");
    // https://stackoverflow.com/questions/39766555/how-to-check-for-empty-string-null-or-white-spaces-in-handlebar
    Handlebars.registerHelper('ifEmptyOrWhitespace', function (value, options) {
        if (!value) {
            return options.fn(this);
        }
        return value.replace(/\s*/g, '').length === 0
            ? options.fn(this)
            : options.inverse(this);
    });
    Handlebars.registerHelper('isZeroThenBlank', function (value) {
        if (Number.isFinite(value)) {
            if (value == 0) {
                return '';
            }
            return value;
        }
        return '';
    });
    Handlebars.registerHelper('isZero', (value) => {
        if (Number.isFinite(value)) {
            return value == 0;
        }
        return true;
    });
    Handlebars.registerHelper('add', (a, b) => {
        if (Number.isFinite(a) && Number.isFinite(b)) {
            return a + b;
        }
        return '';
    });
    Handlebars.registerHelper('sub', (a, b) => {
        if (Number.isFinite(a) && Number.isFinite(b)) {
            return a - b;
        }
        return '';
    });
};
function isEmptyOrSpaces(str) {
    return str === null || str.match(/^[\s\n\r\t]*$/) !== null;
}

const preloadTemplates = async function () {
    const templatePaths = [
        // Add paths to "systems/hellas/templates"
        // Actor Sheets
        `${systemBasePath}/templates/actor/actorSheet.hbs`,
        //Item sheets
        `${systemBasePath}/templates/item/skillSheet.hbs`,
        `${systemBasePath}/templates/item/weaponSheet.hbs`,
        `${systemBasePath}/templates/item/armorSheet.hbs`,
        `${systemBasePath}/templates/item/dynamismSheet.hbs`,
        `${systemBasePath}/templates/item/talentSheet.hbs`,
        // Roll modifier
        `${systemBasePath}/templates/dialog/modifiers.hbs`,
        // Skill roll chat template
        `${systemBasePath}/templates/chat/skillroll.hbs`,
        // Attribute roll chat template
        `${systemBasePath}/templates/chat/attributeroll.hbs`
    ];
    return loadTemplates(templatePaths);
};

const SPECIFY_SUBTYPE = 'specify';
const HELLAS = {
    races: [
        "amazoran",
        "goregon",
        "hellene",
        "kyklope",
        "myrmidon",
        "nephelai",
        "nymphas",
        "zintar"
    ],
    attributes: [],
    attributesWShortName: {
        intelligence: "INT",
        perception: "PER",
        will: "WIL",
        charisma: "CHA",
        strength: "STR",
        constitution: "CON",
        dexterity: "DEX",
        speed: "SPD",
        combatrating: "CR",
        dynamism: "DYN",
        glory: "Glory",
        heropoints: "Hero Points",
        hitpoints: "HP",
        fatepoint: "Fate Points",
        relationship: "Relationship",
        internal: "Internal",
        external: "External",
    },
    attributesShortToLong: {
        "INT": "intelligence",
        "PER": "perception",
        "WIL": "will",
        "CHA": "charisma",
        "STR": "strength",
        "CON": "constitution",
        "DEX": "dexterity",
        "SPD": "speed",
        "CR": "combatrating",
        "DYN": "dynamism",
        "Glory": "glory",
        "Hero Points": "heropoints",
        "HP": "hitpoints",
        "Fate Points": "fatepoint",
        "Relationship": "relationship",
        "Internal": "internal",
        "External": "external"
    },
    characterAttributes: [
        "charisma",
        "constitution",
        "dexterity",
        "intelligence",
        "perception",
        "speed",
        "strength",
        "will",
        "combatrating",
        "dynamism"
    ],
    characterDisadvantages: [
        "relationship",
        "internal",
        "external"
    ],
    initiativeAttribute: "speed",
    skills: [],
    skillsWSpecifics: [],
    skillSpecificsBreakdown: {
        "athletics": ["swimming", "climbing", "balancing", "flying", "jumping", "ropeclimbing", "running", "strengthfeat", "endurance", SPECIFY_SUBTYPE],
        "computers": ["personal", "mainframe", "starship", SPECIFY_SUBTYPE],
        "deception": ['deception', "disguise"],
        "drive": [SPECIFY_SUBTYPE],
        "etiquette": [SPECIFY_SUBTYPE],
        "handicraft": ["alchemy", "armorer", "artificer", "artisan", "bowyerfletcher", "brewervintner", "engineermechanical", "engineerstructural", "gunsmith", "finearts", "vehicles", "weaponsmith", SPECIFY_SUBTYPE],
        "instinct": ["intuition", "initiative"],
        "intimidate": ["words", "physically"],
        "investigatesearch": ["investigationwcha", "investigationwint", "search"],
        "literacy": [SPECIFY_SUBTYPE],
        "lore": ["agriculture", "arcanearts", "engineering", "folklore", "forgery", "gambling", "heraldry", "herblore", "geography", "history", "law", "local", "mining", "nature", "region", "streetwise", "tactics", SPECIFY_SUBTYPE],
        "mode": [],
        "perform": ["dance", "musicianship", "juggling", "acting", "oratory", "singing"],
        "pilot": [SPECIFY_SUBTYPE],
        "profession": [SPECIFY_SUBTYPE],
        "science": ["astronomy", "biology", "botany", "chemistry", "geology", "mathematics", "medicine", "metallurgy", "physics", "xenobiology", "theology", "zoology", SPECIFY_SUBTYPE],
        "sleightofhand": ['perform', 'detect'],
        "speaklanguage": ["atlantean", "goregon", "hellene", "nymphas", "zintar", "zoran", SPECIFY_SUBTYPE],
        "survival": ["savannah", "forest", "jungle", "desert", "arctic", "swamp", "alpine", "aquatic", "urban", SPECIFY_SUBTYPE],
        "torture": [SPECIFY_SUBTYPE],
        "trackingshadowing": ["tracking", "shadowing"],
        "trading": ["appraising", "haggling"],
        "weapon": ["melee", "ranged", "heavyweapons", "guns", "thrown", "vehicleweapons", SPECIFY_SUBTYPE],
    },
    skillSpecificsGetOneOnly: [
        "computers",
        "drive",
        "etiquette",
        "handicraft",
        "instinct",
        "literacy",
        "mode",
        "perform",
        "pilot",
        "profession",
        "science",
        "speaklanguage",
        "survival",
        "weapon",
        "lore"
    ],
    skillSpecificsGetAll: [
        "torture"
    ],
    skillWAssocShortAttributes: {
        athletics: ["CON", "DEX", "SPD", "STR"],
        animalhandling: ["WIL"],
        command: ["CHA"],
        computers: ["INT"],
        deception: ["CHA", "INT"],
        deducemotive: ["PER"],
        diplomacy: ["CHA"],
        disablemechanism: ["DEX"],
        drive: ["DEX"],
        etiquette: ["CHA", "INT"],
        evade: ["DEX"],
        handicraft: ["INT", "STR", "DEX"],
        heal: ["INT"],
        influence: ["CHA"],
        instinct: ["PER", "SPD"],
        intimidate: ["CHA", "STR"],
        investigatesearch: ["CHA", "INT", "PER"],
        literacy: ["INT"],
        lore: ["INT"],
        medicine: ["INT"],
        mode: ["DYN", "PER", "CR"],
        mounted: ["CR"],
        navigate: ["PER"],
        pankration: ["CR"],
        parry: ["CR"],
        perform: ["DEX", "CHA"],
        pilot: ["DEX"],
        profession: ["INT", "PER", "WIL", "CHA", "STR", "CON", "DEX", "SPD", "CR", "DYN"],
        research: ["PER", "INT"],
        resolve: ["WIL"],
        ride: ["DEX"],
        science: ["INT"],
        sleightofhand: ["DEX", "PER"],
        speaklanguage: ["INT"],
        stealth: ["DEX"],
        survival: ["CON", "INT"],
        torture: ["DEX", "INT", "STR"],
        trackingshadowing: ["PER", "DEX"],
        trading: ["INT", "CHA"],
        weapon: ["CR"],
    },
    skillWAssocLongAttributes: {},
    dynamismModes: [],
    dynamismModesSpecificBreakdowns: {
        "attack": ['skill', 'cr'],
        "illusion": ['illusion', 'resist'],
        "influence": ['influence'],
        "kinetic": ['kinetic', 'grapple'],
        "manifest": ['create', 'dematerialize'],
        "manipulate": ['health', 'skill', 'attribute', 'protection', 'minortransform', 'majortransform', 'completetransform'],
        "sensory": ['perception', 'locate', 'scry', 'obscure'],
        "shield": ['aura', 'barrier', 'ward', 'curse'],
    },
    dynamismMode: "mode",
    weaponModifiers: [
        "regular",
        "aether",
        "armorpiercing",
        "beam",
        "bulky",
        "fast",
        "flame",
        "impaling",
        "needle",
        "slugthrower",
        "sonic",
        "torch",
        "vehicularscale"
    ],
    armorModifiers: [
        "regular",
        "energy",
        "aether",
        "holo"
    ],
    armorTypes: {
        "naked": ["nakednudity", "nakedenchantingbeauty"],
        "clothing": ["clothingutility", "clothingofftherack", "clothinghighfashion", "clothingnoblewear"],
        "cuirass": ["cuirasslight", "cuirassmedium", "cuirassheavy"],
        "full": ["fulllight", "fullmedium", "fullheavy"],
        "helmet": ["helmetlight", "helmetmedium", "helmetheavy"],
        "shield": ["shieldlight", "shieldmedium", "shieldheavy", "shielddrone"],
        "shroud": ["shroudclassa", "shroudclassb", "shroudclassc"]
    },
    childrenBorn: [
        "firstborn",
        "secondborn",
        "thirdborn",
        "fourthborn",
        "fifthborn",
        "sxithborn"
    ]
};
HELLAS.attributes = Object.keys(HELLAS.attributesWShortName);
HELLAS.skillsWSpecifics = Object.keys(HELLAS.skillSpecificsBreakdown);
HELLAS.skills = Object.keys(HELLAS.skillWAssocShortAttributes);
HELLAS.dynamismModes = Object.keys(HELLAS.dynamismModesSpecificBreakdowns);
HELLAS.skillSpecificsBreakdown["mode"] = HELLAS.dynamismModes;
// create a shadowed list of long attribute names per skill from the provided list of shortened attribute names
for (let [key, attributes] of Object.entries(HELLAS.skillWAssocShortAttributes)) {
    HELLAS.skillWAssocLongAttributes[key] = attributes.map(value => {
        return HELLAS.attributesShortToLong[value];
    });
}

async function getRollModifiers(baseModifier = 0, dod = 0) {
    const template = `${systemBasePath}/templates/dialog/modifiers.hbs`;
    const html = await renderTemplate(template, {
        dod,
        baseModifier
    });
    return new Promise(resolve => {
        const data = {
            title: game.i18n.localize("HELLAS.roll.modifiers.dialog.title"),
            content: html,
            buttons: {
                cancel: {
                    label: game.i18n.localize("HELLAS.roll.modifiers.dialog.button.cancel.label"),
                    callback: html => resolve({ discriminator: "cancelled" })
                },
                normal: {
                    label: game.i18n.localize("HELLAS.roll.modifiers.dialog.button.roll.label"),
                    callback: html => resolve(_processRollDialog(html[0].querySelector("form")))
                }
            },
            default: "normal",
            close: () => resolve({ discriminator: "cancelled" })
        };
        new Dialog(data, null).render(true);
    });
}
function _processRollDialog(form) {
    const elements = form.elements;
    // @ts-ignore
    return {
        discriminator: "fields",
        dod: parseInt(elements.namedItem('dod').value),
        nonproficiency: parseInt(elements.namedItem('nonproficiency').value),
        multipleactionscount: parseInt(elements.namedItem('multipleactionscount').value),
        modifier: parseInt(elements.namedItem('modifier').value)
    };
}
/**
 * determine the multiple action penalty, including the SPD modifier
 *
 * decide whether SPD should be used as a modifier on multiple actions rolls
 * if the SPD is very high, say 6, then it starts adding to the multiple action penalty
 * and it actually becomes beneficial to take multiple actions which is not intended
 *
 * @param multipleActionsCount the number of multiple actions taken, starting count at zero (ie: the first action is action #0)
 * @param spd character's SPD
 * @returns penalty roll modifier
 */
function multipleActionPenalty(multipleActionsCount, spd) {
    let totalMultipleActionPenalty = multipleActionsCount * -5; // -5 per multiple action, first (counting from zero) is free
    const includeSPDModifier = multipleActionsCount > 0 ? 1 : 0; // if there are multiple actions then = 1, else 0
    const totalSpeedMultipleActionModifier = spd * includeSPDModifier;
    totalMultipleActionPenalty += totalSpeedMultipleActionModifier;
    if (totalMultipleActionPenalty > 0)
        return 0;
    return totalMultipleActionPenalty;
}

// determine the omega table outcome
function determineDieRollOutcome(total) {
    if (total <= 0)
        return 'critfail';
    if (total <= 5)
        return 'fail';
    if (total <= 10)
        return 'partialsuccess';
    if (total <= 19)
        return 'success';
    return 'critsuccess';
}

/** Detect free variable `global` from Node.js. */
var freeGlobal = typeof global == 'object' && global && global.Object === Object && global;

/** Detect free variable `self`. */
var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

/** Used as a reference to the global object. */
var root = freeGlobal || freeSelf || Function('return this')();

/** Built-in value references. */
var Symbol$1 = root.Symbol;

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var nativeObjectToString = objectProto.toString;

/** Built-in value references. */
var symToStringTag = Symbol$1 ? Symbol$1.toStringTag : undefined;

/**
 * A specialized version of `baseGetTag` which ignores `Symbol.toStringTag` values.
 *
 * @private
 * @param {*} value The value to query.
 * @returns {string} Returns the raw `toStringTag`.
 */
function getRawTag(value) {
  var isOwn = hasOwnProperty.call(value, symToStringTag),
      tag = value[symToStringTag];

  try {
    value[symToStringTag] = undefined;
    var unmasked = true;
  } catch (e) {}

  var result = nativeObjectToString.call(value);
  if (unmasked) {
    if (isOwn) {
      value[symToStringTag] = tag;
    } else {
      delete value[symToStringTag];
    }
  }
  return result;
}

/** Used for built-in method references. */
var objectProto$1 = Object.prototype;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var nativeObjectToString$1 = objectProto$1.toString;

/**
 * Converts `value` to a string using `Object.prototype.toString`.
 *
 * @private
 * @param {*} value The value to convert.
 * @returns {string} Returns the converted string.
 */
function objectToString(value) {
  return nativeObjectToString$1.call(value);
}

/** `Object#toString` result references. */
var nullTag = '[object Null]',
    undefinedTag = '[object Undefined]';

/** Built-in value references. */
var symToStringTag$1 = Symbol$1 ? Symbol$1.toStringTag : undefined;

/**
 * The base implementation of `getTag` without fallbacks for buggy environments.
 *
 * @private
 * @param {*} value The value to query.
 * @returns {string} Returns the `toStringTag`.
 */
function baseGetTag(value) {
  if (value == null) {
    return value === undefined ? undefinedTag : nullTag;
  }
  return (symToStringTag$1 && symToStringTag$1 in Object(value))
    ? getRawTag(value)
    : objectToString(value);
}

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */
function isObject(value) {
  var type = typeof value;
  return value != null && (type == 'object' || type == 'function');
}

/** `Object#toString` result references. */
var asyncTag = '[object AsyncFunction]',
    funcTag = '[object Function]',
    genTag = '[object GeneratorFunction]',
    proxyTag = '[object Proxy]';

/**
 * Checks if `value` is classified as a `Function` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a function, else `false`.
 * @example
 *
 * _.isFunction(_);
 * // => true
 *
 * _.isFunction(/abc/);
 * // => false
 */
function isFunction(value) {
  if (!isObject(value)) {
    return false;
  }
  // The use of `Object#toString` avoids issues with the `typeof` operator
  // in Safari 9 which returns 'object' for typed arrays and other constructors.
  var tag = baseGetTag(value);
  return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
}

/** Used to detect overreaching core-js shims. */
var coreJsData = root['__core-js_shared__'];

/** Used to detect methods masquerading as native. */
var maskSrcKey = (function() {
  var uid = /[^.]+$/.exec(coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO || '');
  return uid ? ('Symbol(src)_1.' + uid) : '';
}());

/**
 * Checks if `func` has its source masked.
 *
 * @private
 * @param {Function} func The function to check.
 * @returns {boolean} Returns `true` if `func` is masked, else `false`.
 */
function isMasked(func) {
  return !!maskSrcKey && (maskSrcKey in func);
}

/** Used for built-in method references. */
var funcProto = Function.prototype;

/** Used to resolve the decompiled source of functions. */
var funcToString = funcProto.toString;

/**
 * Converts `func` to its source code.
 *
 * @private
 * @param {Function} func The function to convert.
 * @returns {string} Returns the source code.
 */
function toSource(func) {
  if (func != null) {
    try {
      return funcToString.call(func);
    } catch (e) {}
    try {
      return (func + '');
    } catch (e) {}
  }
  return '';
}

/**
 * Used to match `RegExp`
 * [syntax characters](http://ecma-international.org/ecma-262/7.0/#sec-patterns).
 */
var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;

/** Used to detect host constructors (Safari). */
var reIsHostCtor = /^\[object .+?Constructor\]$/;

/** Used for built-in method references. */
var funcProto$1 = Function.prototype,
    objectProto$2 = Object.prototype;

/** Used to resolve the decompiled source of functions. */
var funcToString$1 = funcProto$1.toString;

/** Used to check objects for own properties. */
var hasOwnProperty$1 = objectProto$2.hasOwnProperty;

/** Used to detect if a method is native. */
var reIsNative = RegExp('^' +
  funcToString$1.call(hasOwnProperty$1).replace(reRegExpChar, '\\$&')
  .replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, '$1.*?') + '$'
);

/**
 * The base implementation of `_.isNative` without bad shim checks.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a native function,
 *  else `false`.
 */
function baseIsNative(value) {
  if (!isObject(value) || isMasked(value)) {
    return false;
  }
  var pattern = isFunction(value) ? reIsNative : reIsHostCtor;
  return pattern.test(toSource(value));
}

/**
 * Gets the value at `key` of `object`.
 *
 * @private
 * @param {Object} [object] The object to query.
 * @param {string} key The key of the property to get.
 * @returns {*} Returns the property value.
 */
function getValue(object, key) {
  return object == null ? undefined : object[key];
}

/**
 * Gets the native function at `key` of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {string} key The key of the method to get.
 * @returns {*} Returns the function if it's native, else `undefined`.
 */
function getNative(object, key) {
  var value = getValue(object, key);
  return baseIsNative(value) ? value : undefined;
}

var defineProperty = (function() {
  try {
    var func = getNative(Object, 'defineProperty');
    func({}, '', {});
    return func;
  } catch (e) {}
}());

/**
 * The base implementation of `assignValue` and `assignMergeValue` without
 * value checks.
 *
 * @private
 * @param {Object} object The object to modify.
 * @param {string} key The key of the property to assign.
 * @param {*} value The value to assign.
 */
function baseAssignValue(object, key, value) {
  if (key == '__proto__' && defineProperty) {
    defineProperty(object, key, {
      'configurable': true,
      'enumerable': true,
      'value': value,
      'writable': true
    });
  } else {
    object[key] = value;
  }
}

/**
 * Performs a
 * [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
 * comparison between two values to determine if they are equivalent.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to compare.
 * @param {*} other The other value to compare.
 * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
 * @example
 *
 * var object = { 'a': 1 };
 * var other = { 'a': 1 };
 *
 * _.eq(object, object);
 * // => true
 *
 * _.eq(object, other);
 * // => false
 *
 * _.eq('a', 'a');
 * // => true
 *
 * _.eq('a', Object('a'));
 * // => false
 *
 * _.eq(NaN, NaN);
 * // => true
 */
function eq(value, other) {
  return value === other || (value !== value && other !== other);
}

/** Used for built-in method references. */
var objectProto$3 = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty$2 = objectProto$3.hasOwnProperty;

/**
 * Assigns `value` to `key` of `object` if the existing value is not equivalent
 * using [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
 * for equality comparisons.
 *
 * @private
 * @param {Object} object The object to modify.
 * @param {string} key The key of the property to assign.
 * @param {*} value The value to assign.
 */
function assignValue(object, key, value) {
  var objValue = object[key];
  if (!(hasOwnProperty$2.call(object, key) && eq(objValue, value)) ||
      (value === undefined && !(key in object))) {
    baseAssignValue(object, key, value);
  }
}

/**
 * Checks if `value` is classified as an `Array` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an array, else `false`.
 * @example
 *
 * _.isArray([1, 2, 3]);
 * // => true
 *
 * _.isArray(document.body.children);
 * // => false
 *
 * _.isArray('abc');
 * // => false
 *
 * _.isArray(_.noop);
 * // => false
 */
var isArray = Array.isArray;

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */
function isObjectLike(value) {
  return value != null && typeof value == 'object';
}

/** `Object#toString` result references. */
var symbolTag = '[object Symbol]';

/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */
function isSymbol(value) {
  return typeof value == 'symbol' ||
    (isObjectLike(value) && baseGetTag(value) == symbolTag);
}

/** Used to match property names within property paths. */
var reIsDeepProp = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
    reIsPlainProp = /^\w*$/;

/**
 * Checks if `value` is a property name and not a property path.
 *
 * @private
 * @param {*} value The value to check.
 * @param {Object} [object] The object to query keys on.
 * @returns {boolean} Returns `true` if `value` is a property name, else `false`.
 */
function isKey(value, object) {
  if (isArray(value)) {
    return false;
  }
  var type = typeof value;
  if (type == 'number' || type == 'symbol' || type == 'boolean' ||
      value == null || isSymbol(value)) {
    return true;
  }
  return reIsPlainProp.test(value) || !reIsDeepProp.test(value) ||
    (object != null && value in Object(object));
}

/* Built-in method references that are verified to be native. */
var nativeCreate = getNative(Object, 'create');

/**
 * Removes all key-value entries from the hash.
 *
 * @private
 * @name clear
 * @memberOf Hash
 */
function hashClear() {
  this.__data__ = nativeCreate ? nativeCreate(null) : {};
  this.size = 0;
}

/**
 * Removes `key` and its value from the hash.
 *
 * @private
 * @name delete
 * @memberOf Hash
 * @param {Object} hash The hash to modify.
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function hashDelete(key) {
  var result = this.has(key) && delete this.__data__[key];
  this.size -= result ? 1 : 0;
  return result;
}

/** Used to stand-in for `undefined` hash values. */
var HASH_UNDEFINED = '__lodash_hash_undefined__';

/** Used for built-in method references. */
var objectProto$4 = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty$3 = objectProto$4.hasOwnProperty;

/**
 * Gets the hash value for `key`.
 *
 * @private
 * @name get
 * @memberOf Hash
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function hashGet(key) {
  var data = this.__data__;
  if (nativeCreate) {
    var result = data[key];
    return result === HASH_UNDEFINED ? undefined : result;
  }
  return hasOwnProperty$3.call(data, key) ? data[key] : undefined;
}

/** Used for built-in method references. */
var objectProto$5 = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty$4 = objectProto$5.hasOwnProperty;

/**
 * Checks if a hash value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf Hash
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function hashHas(key) {
  var data = this.__data__;
  return nativeCreate ? (data[key] !== undefined) : hasOwnProperty$4.call(data, key);
}

/** Used to stand-in for `undefined` hash values. */
var HASH_UNDEFINED$1 = '__lodash_hash_undefined__';

/**
 * Sets the hash `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf Hash
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the hash instance.
 */
function hashSet(key, value) {
  var data = this.__data__;
  this.size += this.has(key) ? 0 : 1;
  data[key] = (nativeCreate && value === undefined) ? HASH_UNDEFINED$1 : value;
  return this;
}

/**
 * Creates a hash object.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function Hash(entries) {
  var index = -1,
      length = entries == null ? 0 : entries.length;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

// Add methods to `Hash`.
Hash.prototype.clear = hashClear;
Hash.prototype['delete'] = hashDelete;
Hash.prototype.get = hashGet;
Hash.prototype.has = hashHas;
Hash.prototype.set = hashSet;

/**
 * Removes all key-value entries from the list cache.
 *
 * @private
 * @name clear
 * @memberOf ListCache
 */
function listCacheClear() {
  this.__data__ = [];
  this.size = 0;
}

/**
 * Gets the index at which the `key` is found in `array` of key-value pairs.
 *
 * @private
 * @param {Array} array The array to inspect.
 * @param {*} key The key to search for.
 * @returns {number} Returns the index of the matched value, else `-1`.
 */
function assocIndexOf(array, key) {
  var length = array.length;
  while (length--) {
    if (eq(array[length][0], key)) {
      return length;
    }
  }
  return -1;
}

/** Used for built-in method references. */
var arrayProto = Array.prototype;

/** Built-in value references. */
var splice = arrayProto.splice;

/**
 * Removes `key` and its value from the list cache.
 *
 * @private
 * @name delete
 * @memberOf ListCache
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function listCacheDelete(key) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  if (index < 0) {
    return false;
  }
  var lastIndex = data.length - 1;
  if (index == lastIndex) {
    data.pop();
  } else {
    splice.call(data, index, 1);
  }
  --this.size;
  return true;
}

/**
 * Gets the list cache value for `key`.
 *
 * @private
 * @name get
 * @memberOf ListCache
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function listCacheGet(key) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  return index < 0 ? undefined : data[index][1];
}

/**
 * Checks if a list cache value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf ListCache
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function listCacheHas(key) {
  return assocIndexOf(this.__data__, key) > -1;
}

/**
 * Sets the list cache `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf ListCache
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the list cache instance.
 */
function listCacheSet(key, value) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  if (index < 0) {
    ++this.size;
    data.push([key, value]);
  } else {
    data[index][1] = value;
  }
  return this;
}

/**
 * Creates an list cache object.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function ListCache(entries) {
  var index = -1,
      length = entries == null ? 0 : entries.length;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

// Add methods to `ListCache`.
ListCache.prototype.clear = listCacheClear;
ListCache.prototype['delete'] = listCacheDelete;
ListCache.prototype.get = listCacheGet;
ListCache.prototype.has = listCacheHas;
ListCache.prototype.set = listCacheSet;

/* Built-in method references that are verified to be native. */
var Map = getNative(root, 'Map');

/**
 * Removes all key-value entries from the map.
 *
 * @private
 * @name clear
 * @memberOf MapCache
 */
function mapCacheClear() {
  this.size = 0;
  this.__data__ = {
    'hash': new Hash,
    'map': new (Map || ListCache),
    'string': new Hash
  };
}

/**
 * Checks if `value` is suitable for use as unique object key.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is suitable, else `false`.
 */
function isKeyable(value) {
  var type = typeof value;
  return (type == 'string' || type == 'number' || type == 'symbol' || type == 'boolean')
    ? (value !== '__proto__')
    : (value === null);
}

/**
 * Gets the data for `map`.
 *
 * @private
 * @param {Object} map The map to query.
 * @param {string} key The reference key.
 * @returns {*} Returns the map data.
 */
function getMapData(map, key) {
  var data = map.__data__;
  return isKeyable(key)
    ? data[typeof key == 'string' ? 'string' : 'hash']
    : data.map;
}

/**
 * Removes `key` and its value from the map.
 *
 * @private
 * @name delete
 * @memberOf MapCache
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function mapCacheDelete(key) {
  var result = getMapData(this, key)['delete'](key);
  this.size -= result ? 1 : 0;
  return result;
}

/**
 * Gets the map value for `key`.
 *
 * @private
 * @name get
 * @memberOf MapCache
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function mapCacheGet(key) {
  return getMapData(this, key).get(key);
}

/**
 * Checks if a map value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf MapCache
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function mapCacheHas(key) {
  return getMapData(this, key).has(key);
}

/**
 * Sets the map `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf MapCache
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the map cache instance.
 */
function mapCacheSet(key, value) {
  var data = getMapData(this, key),
      size = data.size;

  data.set(key, value);
  this.size += data.size == size ? 0 : 1;
  return this;
}

/**
 * Creates a map cache object to store key-value pairs.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function MapCache(entries) {
  var index = -1,
      length = entries == null ? 0 : entries.length;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

// Add methods to `MapCache`.
MapCache.prototype.clear = mapCacheClear;
MapCache.prototype['delete'] = mapCacheDelete;
MapCache.prototype.get = mapCacheGet;
MapCache.prototype.has = mapCacheHas;
MapCache.prototype.set = mapCacheSet;

/** Error message constants. */
var FUNC_ERROR_TEXT = 'Expected a function';

/**
 * Creates a function that memoizes the result of `func`. If `resolver` is
 * provided, it determines the cache key for storing the result based on the
 * arguments provided to the memoized function. By default, the first argument
 * provided to the memoized function is used as the map cache key. The `func`
 * is invoked with the `this` binding of the memoized function.
 *
 * **Note:** The cache is exposed as the `cache` property on the memoized
 * function. Its creation may be customized by replacing the `_.memoize.Cache`
 * constructor with one whose instances implement the
 * [`Map`](http://ecma-international.org/ecma-262/7.0/#sec-properties-of-the-map-prototype-object)
 * method interface of `clear`, `delete`, `get`, `has`, and `set`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to have its output memoized.
 * @param {Function} [resolver] The function to resolve the cache key.
 * @returns {Function} Returns the new memoized function.
 * @example
 *
 * var object = { 'a': 1, 'b': 2 };
 * var other = { 'c': 3, 'd': 4 };
 *
 * var values = _.memoize(_.values);
 * values(object);
 * // => [1, 2]
 *
 * values(other);
 * // => [3, 4]
 *
 * object.a = 2;
 * values(object);
 * // => [1, 2]
 *
 * // Modify the result cache.
 * values.cache.set(object, ['a', 'b']);
 * values(object);
 * // => ['a', 'b']
 *
 * // Replace `_.memoize.Cache`.
 * _.memoize.Cache = WeakMap;
 */
function memoize(func, resolver) {
  if (typeof func != 'function' || (resolver != null && typeof resolver != 'function')) {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  var memoized = function() {
    var args = arguments,
        key = resolver ? resolver.apply(this, args) : args[0],
        cache = memoized.cache;

    if (cache.has(key)) {
      return cache.get(key);
    }
    var result = func.apply(this, args);
    memoized.cache = cache.set(key, result) || cache;
    return result;
  };
  memoized.cache = new (memoize.Cache || MapCache);
  return memoized;
}

// Expose `MapCache`.
memoize.Cache = MapCache;

/** Used as the maximum memoize cache size. */
var MAX_MEMOIZE_SIZE = 500;

/**
 * A specialized version of `_.memoize` which clears the memoized function's
 * cache when it exceeds `MAX_MEMOIZE_SIZE`.
 *
 * @private
 * @param {Function} func The function to have its output memoized.
 * @returns {Function} Returns the new memoized function.
 */
function memoizeCapped(func) {
  var result = memoize(func, function(key) {
    if (cache.size === MAX_MEMOIZE_SIZE) {
      cache.clear();
    }
    return key;
  });

  var cache = result.cache;
  return result;
}

/** Used to match property names within property paths. */
var rePropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;

/** Used to match backslashes in property paths. */
var reEscapeChar = /\\(\\)?/g;

/**
 * Converts `string` to a property path array.
 *
 * @private
 * @param {string} string The string to convert.
 * @returns {Array} Returns the property path array.
 */
var stringToPath = memoizeCapped(function(string) {
  var result = [];
  if (string.charCodeAt(0) === 46 /* . */) {
    result.push('');
  }
  string.replace(rePropName, function(match, number, quote, subString) {
    result.push(quote ? subString.replace(reEscapeChar, '$1') : (number || match));
  });
  return result;
});

/**
 * A specialized version of `_.map` for arrays without support for iteratee
 * shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @returns {Array} Returns the new mapped array.
 */
function arrayMap(array, iteratee) {
  var index = -1,
      length = array == null ? 0 : array.length,
      result = Array(length);

  while (++index < length) {
    result[index] = iteratee(array[index], index, array);
  }
  return result;
}

/** Used as references for various `Number` constants. */
var INFINITY = 1 / 0;

/** Used to convert symbols to primitives and strings. */
var symbolProto = Symbol$1 ? Symbol$1.prototype : undefined,
    symbolToString = symbolProto ? symbolProto.toString : undefined;

/**
 * The base implementation of `_.toString` which doesn't convert nullish
 * values to empty strings.
 *
 * @private
 * @param {*} value The value to process.
 * @returns {string} Returns the string.
 */
function baseToString(value) {
  // Exit early for strings to avoid a performance hit in some environments.
  if (typeof value == 'string') {
    return value;
  }
  if (isArray(value)) {
    // Recursively convert values (susceptible to call stack limits).
    return arrayMap(value, baseToString) + '';
  }
  if (isSymbol(value)) {
    return symbolToString ? symbolToString.call(value) : '';
  }
  var result = (value + '');
  return (result == '0' && (1 / value) == -INFINITY) ? '-0' : result;
}

/**
 * Converts `value` to a string. An empty string is returned for `null`
 * and `undefined` values. The sign of `-0` is preserved.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to convert.
 * @returns {string} Returns the converted string.
 * @example
 *
 * _.toString(null);
 * // => ''
 *
 * _.toString(-0);
 * // => '-0'
 *
 * _.toString([1, 2, 3]);
 * // => '1,2,3'
 */
function toString(value) {
  return value == null ? '' : baseToString(value);
}

/**
 * Casts `value` to a path array if it's not one.
 *
 * @private
 * @param {*} value The value to inspect.
 * @param {Object} [object] The object to query keys on.
 * @returns {Array} Returns the cast property path array.
 */
function castPath(value, object) {
  if (isArray(value)) {
    return value;
  }
  return isKey(value, object) ? [value] : stringToPath(toString(value));
}

/** Used as references for various `Number` constants. */
var MAX_SAFE_INTEGER = 9007199254740991;

/** Used to detect unsigned integer values. */
var reIsUint = /^(?:0|[1-9]\d*)$/;

/**
 * Checks if `value` is a valid array-like index.
 *
 * @private
 * @param {*} value The value to check.
 * @param {number} [length=MAX_SAFE_INTEGER] The upper bounds of a valid index.
 * @returns {boolean} Returns `true` if `value` is a valid index, else `false`.
 */
function isIndex(value, length) {
  var type = typeof value;
  length = length == null ? MAX_SAFE_INTEGER : length;

  return !!length &&
    (type == 'number' ||
      (type != 'symbol' && reIsUint.test(value))) &&
        (value > -1 && value % 1 == 0 && value < length);
}

/** Used as references for various `Number` constants. */
var INFINITY$1 = 1 / 0;

/**
 * Converts `value` to a string key if it's not a string or symbol.
 *
 * @private
 * @param {*} value The value to inspect.
 * @returns {string|symbol} Returns the key.
 */
function toKey(value) {
  if (typeof value == 'string' || isSymbol(value)) {
    return value;
  }
  var result = (value + '');
  return (result == '0' && (1 / value) == -INFINITY$1) ? '-0' : result;
}

/**
 * The base implementation of `_.set`.
 *
 * @private
 * @param {Object} object The object to modify.
 * @param {Array|string} path The path of the property to set.
 * @param {*} value The value to set.
 * @param {Function} [customizer] The function to customize path creation.
 * @returns {Object} Returns `object`.
 */
function baseSet(object, path, value, customizer) {
  if (!isObject(object)) {
    return object;
  }
  path = castPath(path, object);

  var index = -1,
      length = path.length,
      lastIndex = length - 1,
      nested = object;

  while (nested != null && ++index < length) {
    var key = toKey(path[index]),
        newValue = value;

    if (key === '__proto__' || key === 'constructor' || key === 'prototype') {
      return object;
    }

    if (index != lastIndex) {
      var objValue = nested[key];
      newValue = customizer ? customizer(objValue, key, nested) : undefined;
      if (newValue === undefined) {
        newValue = isObject(objValue)
          ? objValue
          : (isIndex(path[index + 1]) ? [] : {});
      }
    }
    assignValue(nested, key, newValue);
    nested = nested[key];
  }
  return object;
}

/**
 * Sets the value at `path` of `object`. If a portion of `path` doesn't exist,
 * it's created. Arrays are created for missing index properties while objects
 * are created for all other missing properties. Use `_.setWith` to customize
 * `path` creation.
 *
 * **Note:** This method mutates `object`.
 *
 * @static
 * @memberOf _
 * @since 3.7.0
 * @category Object
 * @param {Object} object The object to modify.
 * @param {Array|string} path The path of the property to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns `object`.
 * @example
 *
 * var object = { 'a': [{ 'b': { 'c': 3 } }] };
 *
 * _.set(object, 'a[0].b.c', 4);
 * console.log(object.a[0].b.c);
 * // => 4
 *
 * _.set(object, ['x', '0', 'y', 'z'], 5);
 * console.log(object.x[0].y.z);
 * // => 5
 */
function set(object, path, value) {
  return object == null ? object : baseSet(object, path, value);
}

const DEFAULT_SKILL_IMG = 'icons/svg/lightning.svg';
class HellasSkillItem extends Item {
    static get type() {
        return "skill";
    }
    /**
     * Create a new entity using provided input data
     * @override
     */
    static async create(data, options = {}) {
        data.img = data.img || DEFAULT_SKILL_IMG;
        return super.create(data, options);
    }
    prepareData() {
        // Override common default icon
        if (!this.data.img)
            this.data.img = DEFAULT_SKILL_IMG;
        super.prepareData();
        const itemData = this.data.data || {};
        // @ts-ignore
        if (isEmptyOrSpaces(itemData.skill || '')) {
            if (isEmptyOrSpaces(this.data.name))
                this.data.name = game.i18n.localize("HELLAS.item.skill.new");
        }
        else {
            this.processSpecifiersForSkills(itemData);
            this.determineRating(itemData);
            this.data.name = this.fullName();
        }
        // @ts-ignore
        itemData.name = this.data.name;
        // @ts-ignore
        this.data.name = itemData.name;
        // @ts-ignore
        if (this.name !== itemData.name) {
            const data = {
                _id: this._id,
                // @ts-ignore
                name: itemData.name
            };
            if (!!this.actor)
                this.actor.updateOwnedItem(data).catch(reason => console.log(reason));
            else
                this.update(data).catch(reason => console.log(reason));
        }
    }
    processSpecifiersForSkills(data) {
        let changes = {
            _id: this._id
        };
        if (!data.skill) {
            changes = set(changes, "data.skill", HELLAS.skills[0]);
            data.skill = HELLAS.skills[0];
        }
        if (HELLAS.skillsWSpecifics.includes(data.skill)) {
            const specifiers = HELLAS.skillSpecificsBreakdown[data.skill];
            if (!specifiers.includes(data.specifier)) {
                changes = set(changes, "data.specifier", specifiers[0]);
                data.specifier = specifiers[0];
            }
            if (data.skill === HELLAS.dynamismMode) {
                const types = HELLAS.dynamismModesSpecificBreakdowns[data.specifier];
                if (!types.includes(data.specifierCustom)) {
                    changes = set(changes, "data.specifierCustom", types[0]);
                    data.specifierCustom = types[0];
                }
            }
            else if (data.specifier !== SPECIFY_SUBTYPE) {
                changes = set(changes, 'data.specifierCustom', '');
                data.specifierCustom = '';
            }
        }
        else {
            changes = set(changes, "data.specifier", '');
            changes = set(changes, "data.specifierCustom", '');
            data.specifier = '';
            data.specifierCustom = '';
        }
        if (isEmptyOrSpaces(data.attribute) || !HELLAS.skillWAssocShortAttributes[data.skill].includes(data.attribute)) {
            data.attribute = HELLAS.skillWAssocShortAttributes[data.skill][0];
            changes = set(changes, "data.attribute", data.attribute);
        }
        // `skillid` is used to uniquely identify a skill based on the attribute/specifier/custom
        // this is used which skill to associate with a dynamism (spell) when defining them
        const skillid = [data.skill, data.specifier, data.specifierCustom].join('.');
        if (data.skillid !== skillid && !!this.actor) {
            data.skillid = skillid;
            changes = set(changes, "data.skillid", skillid);
            this.actor.updateOwnedItem(changes).catch(reason => console.log(reason));
        }
        this.data.data = data;
    }
    determineRating(data) {
        let changes = {
            _id: this._id
        };
        let max = data.level.max;
        if (!this.actor) {
            max = data.level.value;
        }
        else {
            const actorData = this.actor.data.data;
            const attribute = HELLAS.attributesShortToLong[data.attribute];
            // @ts-ignore
            const attributeValue = actorData.attributes[attribute]['value'];
            max = data.level.value + attributeValue;
        }
        if (data.level.max !== max) {
            data.level.max = max;
            this.data.data = data;
            if (!!this.actor) {
                changes = set(changes, "data.level.max", data.level.max);
                this.actor.updateOwnedItem(changes).catch(reason => console.log(reason));
            }
        }
        else
            this.data.data = data;
    }
    fullName() {
        // @ts-ignore
        const skillName = this.data.data.skill || '';
        if (isEmptyOrSpaces(skillName)) {
            return game.i18n.localize("HELLAS.item.skill.new");
        }
        let workingil8nName = game.i18n.localize("HELLAS.skills." + skillName + ".name");
        if (!HELLAS.skillsWSpecifics.includes(skillName)) {
            return workingil8nName;
        }
        // @ts-ignore
        let specifier = this.data.data.specifier || '';
        // @ts-ignore
        const specifierCustom = this.data.data.specifierCustom || '';
        if (skillName === HELLAS.dynamismMode) {
            workingil8nName = game.i18n.localize("HELLAS.skills.mode.short.name");
            const specifieril8nName = game.i18n.localize("HELLAS.skills.specifics." + specifier);
            if (specifierCustom === specifier || !this.actor)
                return game.i18n.format("HELLAS.item.skill.name.combiner", { skill: workingil8nName, specifier: specifieril8nName });
            else {
                const typeil8nName = game.i18n.localize("HELLAS.skills.mode." + specifierCustom);
                return game.i18n.format("HELLAS.item.skill.name.combiner2", { skill: workingil8nName, specifier: specifieril8nName, type: typeil8nName });
            }
        }
        else {
            if (skillName === 'perform' && !this.actor) {
                return game.i18n.format("HELLAS.item.skill.name.combiner", { skill: workingil8nName, specifier: game.i18n.localize("HELLAS.skills.specifics.specify") });
            }
            else if (HELLAS.skillSpecificsGetAll.includes(skillName) && !this.actor) {
                return game.i18n.format("HELLAS.item.skill.name.combiner", { skill: workingil8nName, specifier: '*' });
            }
            else if (SPECIFY_SUBTYPE === specifier && !isEmptyOrSpaces(specifierCustom)) {
                return game.i18n.format("HELLAS.item.skill.name.combiner", { skill: workingil8nName, specifier: specifierCustom });
            }
            else if (!isEmptyOrSpaces(specifier)) {
                const specifieril8nName = game.i18n.localize("HELLAS.skills.specifics." + specifier);
                return game.i18n.format("HELLAS.item.skill.name.combiner", { skill: workingil8nName, specifier: specifieril8nName });
            }
        }
        return workingil8nName;
    }
    /**
     * Handle clickable rolls.
     */
    async roll() {
        if (!this.actor)
            return false;
        const actorData = this.actor.data.data;
        const item = this.data;
        const itemData = item.data;
        let modifierOverall = 0;
        // if we are rolling a 'parry' skill, check to see if there is
        // armor modifiers for parrying (from shields etc...)
        if (itemData.skill === 'parry') {
            modifierOverall = actorData.modifiers.armor.parry;
        }
        // if we are rolling a skill whose attribute is modified by armor
        // then determine that modifier
        if (actorData.modifiers.armor.hasOwnProperty(HELLAS.attributesShortToLong[itemData.attribute])) {
            modifierOverall += actorData.modifiers.armor[HELLAS.attributesShortToLong[itemData.attribute]];
        }
        // get modifier data
        const modifiers = await getRollModifiers(modifierOverall);
        if (modifiers.discriminator == "cancelled")
            return false;
        let rollData = mergeObject({
            multipleactionspenalty: multipleActionPenalty(modifiers.multipleactionscount, actorData.attributes.speed.value)
        }, modifiers);
        rollData = mergeObject(rollData, itemData);
        const roll = new Roll('d20 + @level.max + @dod + @nonproficiency + @multipleactionspenalty + @modifier', rollData).roll();
        const outcome = determineDieRollOutcome(roll.total);
        const template = `${systemBasePath}/templates/chat/skillroll.hbs`;
        const html = await renderTemplate(template, {
            name: item.name,
            outcome: outcome,
            data: rollData,
        });
        await roll.toMessage({
            speaker: ChatMessage.getSpeaker({ actor: this.actor }),
            flavor: html
        }, { rollMode: CONFIG.Dice.rollModes.PUBLIC });
        return true;
    }
}

const DEFAULT_WEAPON_SKILLID = 'combatrating';
const DEFAULT_WEAPON_IMG = 'icons/svg/sword.svg';
class HellasWeaponItem extends Item {
    static get type() {
        return "weapon";
    }
    /**
     * Create a new entity using provided input data
     * @override
     */
    static async create(data, options = {}) {
        data.img = data.img || DEFAULT_WEAPON_IMG;
        return super.create(data, options);
    }
    prepareData() {
        // Override common default icon
        if (!this.data.img)
            this.data.img = DEFAULT_WEAPON_IMG;
        super.prepareData();
        const itemData = (this.data.data || {});
        if (isEmptyOrSpaces(this.data.name))
            this.data.name = game.i18n.localize("HELLAS.item.weapon.new");
        // @ts-ignore
        itemData.name = this.data.name;
        // @ts-ignore
        this.data.name = itemData.name;
        itemData.skillid = itemData.skillid || DEFAULT_WEAPON_SKILLID;
        if (!this.actor) {
            // if we don't belong to an actor, then default the 'skillid'
            if (itemData.skillid !== DEFAULT_WEAPON_SKILLID) {
                const changeData = {
                    _id: this._id,
                    data: {
                        "skillid": DEFAULT_WEAPON_SKILLID
                    }
                };
                this.update(changeData).catch(reason => console.log(reason));
            }
        }
    }
    /**
     * Handle clickable rolls.
     */
    async roll() {
        if (!this.actor)
            return false;
        const actorData = this.actor.data.data;
        const item = this.data;
        const itemData = item.data || {};
        let weaponRollingPenalty = 0;
        /**
         * Note that skills store their assigned level in `level.value`, then add their associated attribute with the result being
         * `level.max`, while character attributes store their assigned level in `max` and then store modified rollable values in `value`
         */
        const characterSTR = actorData.attributes.strength.value;
        /**
         * if a character's STR is less than the minimum required by the weapon to handle
         * then the weapons suffers a (-2 * delta) penalty, if the weapon is a missile weapon then
         * the penalty is (-4 * delta)
         */
        if (characterSTR < itemData.str) {
            const delta = itemData.str - characterSTR;
            weaponRollingPenalty += delta * ((!!itemData.ismissile) ? -4 : -2);
        }
        weaponRollingPenalty += itemData.acc;
        // get modifier data
        const modifiers = await getRollModifiers(weaponRollingPenalty);
        if (modifiers.discriminator == "cancelled")
            return false;
        let baseLevel = 0;
        let skillName = '';
        if (itemData.skillid === DEFAULT_WEAPON_SKILLID) {
            baseLevel = actorData.attributes[DEFAULT_WEAPON_SKILLID].value;
            skillName = game.i18n.localize(`HELLAS.attributes.${DEFAULT_WEAPON_SKILLID}.name`);
        }
        else {
            const skill = this.actor.getOwnedItem(itemData.skillid);
            if (!skill) {
                ui.notifications.error(`No associated skill found for ${item.name}`);
                return false;
            }
            const skillData = skill.data;
            baseLevel = skillData.data.level.max;
            skillName = skillData.name;
        }
        let rollData = mergeObject({
            multipleactionspenalty: multipleActionPenalty(modifiers.multipleactionscount, actorData.attributes.speed.value),
            baseLevel
        }, modifiers);
        const roll = new Roll('d20 + @baseLevel + @dod + @nonproficiency + @multipleactionspenalty + @modifier', rollData).roll();
        const outcome = determineDieRollOutcome(roll.total);
        const template = `${systemBasePath}/templates/chat/weaponroll.hbs`;
        const html = await renderTemplate(template, {
            name: this.name,
            skill: skillName,
            outcome: outcome,
            data: rollData,
        });
        await roll.toMessage({
            speaker: ChatMessage.getSpeaker({ actor: this.actor }),
            flavor: html
        }, { rollMode: CONFIG.Dice.rollModes.PUBLIC });
        return true;
    }
}

const DEFAULT_ARMOR_IMG = 'icons/svg/shield.svg';
class HellasArmorItem extends Item {
    static get type() {
        return "armor";
    }
    /**
     * Create a new entity using provided input data
     * @override
     */
    static async create(data, options = {}) {
        data.img = data.img || DEFAULT_ARMOR_IMG;
        return super.create(data, options);
    }
    prepareData() {
        // Override common default icon
        if (!this.data.img)
            this.data.img = DEFAULT_ARMOR_IMG;
        super.prepareData();
        const itemData = (this.data.data || {});
        if (isEmptyOrSpaces(this.data.name))
            this.data.name = game.i18n.localize("HELLAS.item.armor.new");
        // @ts-ignore
        itemData.name = this.data.name;
        // @ts-ignore
        this.data.name = itemData.name;
        if (!this.actor) ;
    }
    toggleActive() {
        if (!this.actor)
            return false;
        const item = this.data;
        const itemData = item.data || {};
        itemData.active = !itemData.active;
        const changeData = {
            _id: this._id,
            data: {
                "active": itemData.active
            }
        };
        this.update(changeData).catch(reason => console.log(reason));
        return true;
    }
}

const DEFAULT_DYNAMISM_SKILLID = 'dynamism';
const DEFAULT_DYNAMISM_IMG = 'icons/svg/lightning.svg';
class HellasDynamismItem extends Item {
    static get type() {
        return "dynamism";
    }
    /**
     * Create a new entity using provided input data
     * @override
     */
    static async create(data, options = {}) {
        data.img = data.img || DEFAULT_DYNAMISM_IMG;
        return super.create(data, options);
    }
    prepareData() {
        // Override common default icon
        if (!this.data.img)
            this.data.img = DEFAULT_DYNAMISM_IMG;
        super.prepareData();
        const itemData = (this.data.data || {});
        if (isEmptyOrSpaces(this.data.name))
            this.data.name = game.i18n.localize("HELLAS.item.dynamism.new");
        // @ts-ignore
        itemData.name = this.data.name;
        // @ts-ignore
        this.data.name = itemData.name;
        itemData.skillid = itemData.skillid || DEFAULT_DYNAMISM_SKILLID;
        if (!this.actor) {
            // if we don't belong to an actor, then default the 'skillid'
            if (itemData.skillid !== DEFAULT_DYNAMISM_SKILLID) {
                const changeData = {
                    _id: this._id,
                    data: {
                        "skillid": DEFAULT_DYNAMISM_SKILLID
                    }
                };
                this.update(changeData).catch(reason => console.log(reason));
            }
        }
    }
    /**
     * Handle clickable rolls.
     */
    async roll() {
        if (!this.actor)
            return false;
        const actorData = this.actor.data.data;
        const item = this.data;
        const itemData = item.data || {};
        const dod = itemData.dod;
        if (itemData.skillid === DEFAULT_DYNAMISM_SKILLID) {
            ui.notifications.error(`You must first pick a specific dynamism skill for ${item.name}. Edit the dynamism and pick the correct mode skill.`);
            return false;
        }
        // get modifier data
        const modifiers = await getRollModifiers(0, dod);
        if (modifiers.discriminator == "cancelled")
            return false;
        let baseLevel = 0;
        let skillName = '';
        const skill = this.actor.getOwnedItem(itemData.skillid);
        if (!skill) {
            ui.notifications.error(`No associated skill found for ${item.name}`);
            return false;
        }
        const skillData = skill.data;
        baseLevel = skillData.data.level.max;
        skillName = skillData.name;
        let rollData = mergeObject({
            multipleactionspenalty: multipleActionPenalty(modifiers.multipleactionscount, actorData.attributes.speed.value),
            baseLevel
        }, modifiers);
        const roll = new Roll('d20 + @baseLevel + @dod + @nonproficiency + @multipleactionspenalty + @modifier', rollData).roll();
        const outcome = determineDieRollOutcome(roll.total);
        const template = `${systemBasePath}/templates/chat/dynamismroll.hbs`;
        const html = await renderTemplate(template, {
            name: this.name,
            skill: skillName,
            outcome: outcome,
            data: rollData,
        });
        await roll.toMessage({
            speaker: ChatMessage.getSpeaker({ actor: this.actor }),
            flavor: html
        }, { rollMode: CONFIG.Dice.rollModes.PUBLIC });
        return true;
    }
}

const DEFAULT_TALENT_IMG = 'icons/svg/sun.svg';
class HellasTalentItem extends Item {
    static get type() {
        return "talent";
    }
    /**
     * Create a new entity using provided input data
     * @override
     */
    static async create(data, options = {}) {
        data.img = data.img || DEFAULT_TALENT_IMG;
        return super.create(data, options);
    }
    prepareData() {
        // Override common default icon
        if (!this.data.img)
            this.data.img = DEFAULT_TALENT_IMG;
        super.prepareData();
        const itemData = (this.data.data || {});
        if (isEmptyOrSpaces(this.data.name))
            this.data.name = game.i18n.localize("HELLAS.item.talent.new");
        // @ts-ignore
        itemData.name = this.data.name;
        // @ts-ignore
        this.data.name = itemData.name;
    }
}

/**
 * Extend the basic ActorSheet with some very simple modifications
 * @extends {ActorSheet}
 */
const sortItemsByNameFunction = (a, b) => a.name < b.name ? -1 : a.name > b.name ? 1 : 0;
class HellasActorSheet extends ActorSheet {
    /** @override */
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["hellas", "sheet", "actor"],
            width: 925,
            height: 1000,
            tabs: [{ navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "attributes" }]
        });
    }
    /**
     * Get the correct HTML template path to use for rendering this particular sheet
     * @type {String}
     */
    get template() {
        return `${systemBasePath}/templates/actor/actorSheet.hbs`;
    }
    /* -------------------------------------------- */
    /** @override */
    getData() {
        const sheetData = super.getData();
        // @ts-ignore
        sheetData.dtypes = ["String", "Number", "Boolean"];
        // Prepare items.
        if (this.actor.data.type == 'character') {
            this._prepareAttributes(sheetData);
            this._prepareCharacterItems(sheetData);
        }
        return sheetData;
    }
    _prepareAttributes(sheetData) {
        for (let i = 0; i < HELLAS.characterAttributes.length; i++) {
            const attribute = sheetData.data.attributes[HELLAS.characterAttributes[i]];
            if (!Number.isFinite(attribute.value)) {
                attribute.value = 0;
            }
        }
    }
    /**
     * Organize and classify Items for Character sheets.
     *
     * @param sheetData
     * @return {undefined}
     */
    _prepareCharacterItems(sheetData) {
        var _a, _b, _c, _d, _e, _f, _g, _h;
        // @ts-ignore
        sheetData.data.items = sheetData.actor.items || {};
        // @ts-ignore
        const items = sheetData.data.items;
        // filter out items and sort them
        Object.entries({
            skills: HellasSkillItem.type,
            weapons: HellasWeaponItem.type,
            armor: HellasArmorItem.type,
            dynamism: HellasDynamismItem.type,
            talents: HellasTalentItem.type
        }).forEach(([val, type]) => {
            // @ts-ignore
            if (!sheetData.data.items[val]) {
                sheetData.data.items[val] = items.filter(i => i.type === type).sort(sortItemsByNameFunction);
            }
        });
        // ************************************************************
        // run through the armor that's active and determine what modifiers are present
        // ************************************************************
        // character strength
        const charStrength = sheetData.data.attributes['strength'].value;
        // running totals of armor modifiers
        let totalpr = 0;
        let dexModifier = 0;
        let perModifier = 0;
        let parryModifier = 0;
        // the armor items
        const armorItems = sheetData.data.items['armor'];
        for (let i = 0; i < armorItems.length; i++) {
            const data = armorItems[i].data;
            if (data.active) {
                // this item is active (ie: being worn)
                totalpr += data.pr;
                perModifier += data.per;
                if (data.str > charStrength) {
                    // if armor's str requirement exceeds the character's strength then there is a dex modifier
                    dexModifier += Math.abs(data.str - charStrength);
                }
                parryModifier += data.parry;
            }
        }
        let updateData = {};
        let updateNeeded = false;
        // check whether the totaled modifiers are different than what we have
        // recorded already on the character
        if (((_b = (_a = sheetData.data.modifiers) === null || _a === void 0 ? void 0 : _a.armor) === null || _b === void 0 ? void 0 : _b.dexterity) !== -dexModifier) {
            set(updateData, 'data.modifiers.armor.dexterity', -dexModifier);
            updateNeeded = true;
        }
        if (((_d = (_c = sheetData.data.modifiers) === null || _c === void 0 ? void 0 : _c.armor) === null || _d === void 0 ? void 0 : _d.perception) !== perModifier) {
            set(updateData, 'data.modifiers.armor.perception', perModifier);
            updateNeeded = true;
        }
        if (((_f = (_e = sheetData.data.modifiers) === null || _e === void 0 ? void 0 : _e.armor) === null || _f === void 0 ? void 0 : _f.parry) !== parryModifier) {
            set(updateData, 'data.modifiers.armor.parry', parryModifier);
            updateNeeded = true;
        }
        if (((_h = (_g = sheetData.data.modifiers) === null || _g === void 0 ? void 0 : _g.armor) === null || _h === void 0 ? void 0 : _h.pr) !== totalpr) {
            set(updateData, 'data.modifiers.armor.pr', totalpr);
            updateNeeded = true;
        }
        if (updateNeeded) {
            this.actor.update(updateData).catch(reason => console.log(reason));
        }
    }
    /* -------------------------------------------- */
    /** @override */
    activateListeners(html) {
        super.activateListeners(html);
        // Everything below here is only needed if the sheet is editable
        if (!this.options.editable)
            return;
        // Tooltips
        html.find('.tooltip').tooltipster({
            interactive: true,
            plugins: ['sideTip', 'scrollableTip']
        });
        // Add Item
        html.find('.item-create').click(this._onItemCreate.bind(this));
        // Update Item
        html.find('.item-edit').click(this._onItemEdit.bind(this));
        // Delete Item
        html.find('.item-delete').click(this._onDeleteItem.bind(this));
        // Fate point display
        html.find('.fate-progress').click(this._onFateProgressClick.bind(this));
        // roll an attribute
        html.find('.attr-roll').click(this._onAttrRoll.bind(this));
        // roll a skill
        html.find('.skill-roll').click(this._onSkillRoll.bind(this));
        // roll a weapon
        html.find('.weapon-roll').click(this._onWeaponRoll.bind(this));
        // active/deactivate a piece of armor
        html.find('.armor-active-checkbox').click(this._onArmorActiveClick.bind(this));
        // roll a dynamism
        html.find('.dynamism-roll').click(this._onDynamismRoll.bind(this));
    }
    _onArmorActiveClick(event) {
        event.preventDefault();
        const element = event.currentTarget;
        const itemID = element.dataset.itemId;
        const item = this.actor.getOwnedItem(itemID);
        if (!item)
            return false;
        item.toggleActive();
    }
    _onAttrRoll(event) {
        event.preventDefault();
        const element = event.currentTarget;
        const attribute = element.dataset.itemId;
        const rating = parseInt(element.dataset.rating);
        const actor = this.actor;
        actor.attrRoll(attribute, rating).catch(reason => console.log(reason));
        return false;
    }
    _onSkillRoll(event) {
        event.preventDefault();
        const element = event.currentTarget;
        const itemID = element.dataset.itemId;
        const item = this.actor.getOwnedItem(itemID);
        if (!item)
            return false;
        item.roll().catch(reason => console.log(reason));
        return false;
    }
    _onWeaponRoll(event) {
        event.preventDefault();
        const element = event.currentTarget;
        const itemID = element.dataset.itemId;
        const item = this.actor.getOwnedItem(itemID);
        if (!item)
            return false;
        item.roll().catch(reason => console.log(reason));
        return false;
    }
    _onDynamismRoll(event) {
        event.preventDefault();
        const element = event.currentTarget;
        const itemID = element.dataset.itemId;
        const item = this.actor.getOwnedItem(itemID);
        if (!item)
            return false;
        item.roll().catch(reason => console.log(reason));
        return false;
    }
    /**
     * Handle adding or removing fate points from the character sheet
     * @param event
     */
    _onFateProgressClick(event) {
        event.preventDefault();
        const element = event.currentTarget;
        const fpCount = parseInt(element.dataset.itemId);
        if (isNaN(fpCount))
            return false;
        // @ts-ignore
        this.actor.data.data.attributes.fatepoints.value = fpCount;
        this.render(false);
        return false;
    }
    /**
     * Handle creating a new Owned Item for the actor using initial data defined in the HTML dataset
     * @param {Event} event   The originating click event
     * @private
     */
    _onItemCreate(event) {
        event.preventDefault();
        const element = event.currentTarget;
        // Get the type of item to create.
        const type = element.dataset.type;
        // Grab any data associated with this control.
        const data = duplicate(element.dataset);
        // Initialize a default name.
        const name = game.i18n.localize(`HELLAS.item.${type}.new`);
        // Prepare the item object.
        const itemData = {
            name: name,
            type: type,
            data: data,
        };
        // Remove the type from the dataset since it's in the itemData.type prop.
        delete itemData.data["type"];
        // Finally, create the item!
        return this.actor.createOwnedItem(itemData);
    }
    /**
     * Handle editing an Owned Item
     * @param event
     */
    _onItemEdit(event) {
        event.preventDefault();
        const td = $(event.currentTarget).parents(".item");
        const item = this.actor.getOwnedItem(td.data("itemId"));
        item.sheet.render(true);
        return false;
    }
    /**
     * Handle deleting an Owned Item
     * @param event
     */
    _onDeleteItem(event) {
        event.preventDefault();
        if (window.confirm(game.i18n.localize("HELLAS.dialog.really.delete"))) {
            const td = $(event.currentTarget).parents(".item");
            this.actor.deleteOwnedItem(td.data("itemId"));
            td.slideUp(200, () => this.render(false));
        }
        return false;
    }
}

/**
 * Extend the base Actor entity by defining a custom roll data structure which is ideal for the Simple system.
 * @extends {Actor}
 */
class HellasActor extends Actor {
    prepareData() {
        super.prepareData();
        const actorData = this.data;
        actorData.data;
        if (actorData.type == 'character')
            this._prepareCharacterData(actorData);
    }
    /**
     * Calculate derived values
     *
     * @param actorData
     */
    _prepareCharacterData(actorData) {
        actorData.data;
        this.data['HELLAS'] = HELLAS;
        this.data['SPECIFY_SUBTYPE'] = SPECIFY_SUBTYPE;
    }
    /**
     * Handle clickable attr rolls.
     */
    async attrRoll(attribute, rating) {
        var _a, _b, _c;
        const actorData = this.data.data;
        let modifier = 0;
        if ((_b = (_a = actorData.modifiers) === null || _a === void 0 ? void 0 : _a.armor) === null || _b === void 0 ? void 0 : _b.hasOwnProperty(attribute)) {
            modifier = (_c = actorData.modifiers) === null || _c === void 0 ? void 0 : _c.armor[attribute];
        }
        // get modifier data
        const modifiers = await getRollModifiers(modifier);
        if (modifiers.discriminator == "cancelled")
            return false;
        const rollData = mergeObject({
            multipleactionspenalty: multipleActionPenalty(modifiers.multipleactionscount, actorData.attributes.speed.value),
            attribute: actorData.attributes[attribute]
        }, modifiers);
        const roll = new Roll('d20 + @attribute.value + @dod + @nonproficiency + @multipleactionspenalty + @modifier', rollData).roll();
        const outcome = determineDieRollOutcome(roll.total);
        const template = `${systemBasePath}/templates/chat/attributeroll.hbs`;
        const html = await renderTemplate(template, {
            name: attribute,
            outcome: outcome,
            data: rollData,
        });
        await roll.toMessage({
            speaker: ChatMessage.getSpeaker({ actor: this }),
            flavor: html
        }, { rollMode: CONFIG.Dice.rollModes.PUBLIC });
        return true;
    }
    /**
     * Get a list of skills whose skillid begins with a prefix
     *
     * @param {string} prefix
     * @returns {HellasSkillItem[]}
     */
    getSkillsBySkillIDPrefix(prefix) {
        const items = this.data.items;
        const skills = items.filter(i => { var _a, _b; return i.type === HellasSkillItem.type && ((_b = (_a = i.data) === null || _a === void 0 ? void 0 : _a.skillid) === null || _b === void 0 ? void 0 : _b.startsWith(prefix)); }).sort(sortItemsByNameFunction);
        return skills;
    }
}

/**
 * Maelstrom item base class
 *
 * Acts as a mix of factory and proxy: depending on its "type" argument,
 * creates an object of the right class (also extending Item) and simply
 * overrides its own properties with that of that new objects.
 *
 * This is used since Item doesn't really allow for real inheritance, so
 * we're simply faking it. #yolo #ididntchoosethethuglife
 *
 * @export
 * @class HellasItem
 * @extends {Item}
 */
const HellasItem = new Proxy(function () { }, {
    //Calling a constructor from this proxy object
    construct: function (target, info, ...args) {
        const [data, newTarget] = info;
        switch (data.type) {
            case HellasSkillItem.type:
                return new HellasSkillItem(data, newTarget);
            case HellasWeaponItem.type:
                return new HellasWeaponItem(data, newTarget);
            case HellasArmorItem.type:
                return new HellasArmorItem(data, newTarget);
            case HellasDynamismItem.type:
                return new HellasDynamismItem(data, newTarget);
            case HellasTalentItem.type:
                return new HellasTalentItem(data, newTarget);
        }
    },
    //Property access on this weird, dirty proxy object
    get: function (target, prop, receiver) {
        switch (prop) {
            case "create":
                //Calling the class' create() static function
                return function (data, options) {
                    switch (data.type) {
                        case HellasSkillItem.type:
                            return HellasSkillItem.create(data, options);
                        case HellasWeaponItem.type:
                            return HellasWeaponItem.create(data, options);
                        case HellasArmorItem.type:
                            return HellasArmorItem.create(data, options);
                        case HellasDynamismItem.type:
                            return HellasDynamismItem.create(data, options);
                        case HellasTalentItem.type:
                            return HellasTalentItem.create(data, options);
                    }
                };
            case Symbol.hasInstance:
                //Applying the "instanceof" operator on the instance object
                return function (instance) {
                    return (instance instanceof HellasSkillItem ||
                        HellasWeaponItem ||
                        HellasArmorItem ||
                        HellasDynamismItem ||
                        HellasTalentItem ||
                        // other instanceof
                        false);
                };
            default:
                //Just forward any requested properties to the base Actor class
                return Item[prop];
        }
    },
});

class HellasSkillItemSheet extends ItemSheet {
    /**
     * Define default rendering options for the ability sheet
     * @return {Object}
     */
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["hellas", "sheet", "item"],
            width: 550,
            height: 620,
            tabs: [{ navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "skill" }]
        });
    }
    /* -------------------------------------------- */
    /*  Rendering                                   */
    /* -------------------------------------------- */
    /**
     * Get the correct HTML template path to use for rendering this particular sheet
     * @type {String}
     */
    get template() {
        return `${systemBasePath}/templates/item/${this.type}Sheet.hbs`;
    }
    get type() {
        return HellasSkillItem.type;
    }
    // @ts-ignore
    getData() {
        let sheet = super.getData();
        // determine whether, based on the skill, there are optional specifics and which are the appropriate attributes
        sheet.item['SHORTATTRIBUTELIST'] = HELLAS.skillWAssocShortAttributes[sheet.data.skill];
        if (HELLAS.skillsWSpecifics.includes(sheet.data.skill)) {
            sheet.item['SKILLSPECIFICS'] = HELLAS.skillSpecificsBreakdown[sheet.data.skill];
            if (sheet.data.skill === HELLAS.dynamismMode) {
                if (!sheet.item['SKILLSPECIFICS'].includes(sheet.data.specifier)) {
                    sheet.data.specifier = sheet.item['SKILLSPECIFICS'][0];
                }
                sheet.item['MODESPECIFICS'] = HELLAS.dynamismModesSpecificBreakdowns[sheet.data.specifier];
            }
            else {
                sheet.item['MODESPECIFICS'] = [];
            }
        }
        else {
            sheet.item['MODESPECIFICS'] = [];
            sheet.item['SKILLSPECIFICS'] = [];
        }
        sheet.item['HELLAS'] = HELLAS; // this is being set on the item itself that the handlebars template sees
        sheet.item['SPECIFY_SUBTYPE'] = SPECIFY_SUBTYPE; // this is being set on the item itself that the handlebars template sees
        return sheet;
    }
    /** @override */
    setPosition(options = {}) {
        const position = super.setPosition(options);
        // @ts-ignore
        const sheetBody = this.element.find(".sheet-body");
        const bodyHeight = position.height - 192;
        sheetBody === null || sheetBody === void 0 ? void 0 : sheetBody.css("height", bodyHeight);
        return position;
    }
    /** @override */
    activateListeners(html) {
        super.activateListeners(html);
        // Everything below here is only needed if the sheet is editable
        if (!this.options.editable)
            return;
        // Roll handlers, click handlers, etc. would go here.
    }
}

class HellasWeaponItemSheet extends ItemSheet {
    /**
     * Define default rendering options for the ability sheet
     * @return {Object}
     */
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["hellas", "sheet", "item"],
            width: 550,
            height: 620,
            tabs: [{ navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "weapon" }]
        });
    }
    /* -------------------------------------------- */
    /*  Rendering                                   */
    /* -------------------------------------------- */
    /**
     * Get the correct HTML template path to use for rendering this particular sheet
     * @type {String}
     */
    get template() {
        return `${systemBasePath}/templates/item/${this.type}Sheet.hbs`;
    }
    get type() {
        return HellasWeaponItem.type;
    }
    // @ts-ignore
    getData() {
        let sheet = super.getData();
        sheet.item['HELLAS'] = HELLAS;
        if (this.actor)
            sheet.item['SKILLS'] = this.actor.getSkillsBySkillIDPrefix("weapon");
        else
            sheet.item['SKILLS'] = [];
        return sheet;
    }
    /** @override */
    setPosition(options = {}) {
        const position = super.setPosition(options);
        // @ts-ignore
        const sheetBody = this.element.find(".sheet-body");
        const bodyHeight = position.height - 192;
        sheetBody === null || sheetBody === void 0 ? void 0 : sheetBody.css("height", bodyHeight);
        return position;
    }
    /** @override */
    activateListeners(html) {
        super.activateListeners(html);
        // Everything below here is only needed if the sheet is editable
        if (!this.options.editable)
            return;
        // Roll handlers, click handlers, etc. would go here.
    }
}

class HellasArmorItemSheet extends ItemSheet {
    /**
     * Define default rendering options for the ability sheet
     * @return {Object}
     */
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["hellas", "sheet", "item"],
            width: 550,
            height: 620,
            tabs: [{ navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "armor" }]
        });
    }
    /* -------------------------------------------- */
    /*  Rendering                                   */
    /* -------------------------------------------- */
    /**
     * Get the correct HTML template path to use for rendering this particular sheet
     * @type {String}
     */
    get template() {
        return `${systemBasePath}/templates/item/${this.type}Sheet.hbs`;
    }
    get type() {
        return HellasArmorItem.type;
    }
    // @ts-ignore
    getData() {
        let sheet = super.getData();
        sheet.item['HELLAS'] = HELLAS;
        return sheet;
    }
    /** @override */
    setPosition(options = {}) {
        const position = super.setPosition(options);
        // @ts-ignore
        const sheetBody = this.element.find(".sheet-body");
        const bodyHeight = position.height - 192;
        sheetBody === null || sheetBody === void 0 ? void 0 : sheetBody.css("height", bodyHeight);
        return position;
    }
    /** @override */
    activateListeners(html) {
        super.activateListeners(html);
        // Everything below here is only needed if the sheet is editable
        if (!this.options.editable)
            return;
        // Roll handlers, click handlers, etc. would go here.
    }
}

class HellasDynamismItemSheet extends ItemSheet {
    /**
     * Define default rendering options for the ability sheet
     * @return {Object}
     */
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["hellas", "sheet", "item"],
            width: 550,
            height: 620,
            tabs: [{ navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "dynamism" }]
        });
    }
    /* -------------------------------------------- */
    /*  Rendering                                   */
    /* -------------------------------------------- */
    /**
     * Get the correct HTML template path to use for rendering this particular sheet
     * @type {String}
     */
    get template() {
        return `${systemBasePath}/templates/item/${this.type}Sheet.hbs`;
    }
    get type() {
        return HellasDynamismItem.type;
    }
    // @ts-ignore
    getData() {
        let sheet = super.getData();
        sheet.item['HELLAS'] = HELLAS;
        if (this.actor)
            sheet.item['SKILLS'] = this.actor.getSkillsBySkillIDPrefix("mode");
        else
            sheet.item['SKILLS'] = [];
        return sheet;
    }
    /** @override */
    setPosition(options = {}) {
        const position = super.setPosition(options);
        // @ts-ignore
        const sheetBody = this.element.find(".sheet-body");
        const bodyHeight = position.height - 192;
        sheetBody === null || sheetBody === void 0 ? void 0 : sheetBody.css("height", bodyHeight);
        return position;
    }
    /** @override */
    activateListeners(html) {
        super.activateListeners(html);
        // Everything below here is only needed if the sheet is editable
        if (!this.options.editable)
            return;
        // Roll handlers, click handlers, etc. would go here.
    }
}

class HellasTalentItemSheet extends ItemSheet {
    /**
     * Define default rendering options for the ability sheet
     * @return {Object}
     */
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            classes: ["hellas", "sheet", "item"],
            width: 550,
            height: 620,
            tabs: [{ navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "talent" }]
        });
    }
    /* -------------------------------------------- */
    /*  Rendering                                   */
    /* -------------------------------------------- */
    /**
     * Get the correct HTML template path to use for rendering this particular sheet
     * @type {String}
     */
    get template() {
        return `${systemBasePath}/templates/item/${this.type}Sheet.hbs`;
    }
    get type() {
        return HellasTalentItem.type;
    }
    // @ts-ignore
    getData() {
        let sheet = super.getData();
        sheet.item['HELLAS'] = HELLAS;
        return sheet;
    }
    /** @override */
    setPosition(options = {}) {
        const position = super.setPosition(options);
        // @ts-ignore
        const sheetBody = this.element.find(".sheet-body");
        const bodyHeight = position.height - 192;
        sheetBody === null || sheetBody === void 0 ? void 0 : sheetBody.css("height", bodyHeight);
        return position;
    }
    /** @override */
    activateListeners(html) {
        super.activateListeners(html);
        // Everything below here is only needed if the sheet is editable
        if (!this.options.editable)
            return;
        // Roll handlers, click handlers, etc. would go here.
    }
}

/**
 * Hellas RPG
 *
 * Author: Stephen Smith
 * Content License: [copyright and-or license] If using an existing system
 * 					you may want to put a (link to a) license or copyright
 * 					notice here (e.g. the OGL).
 * Software License: The MIT License (MIT)
 */
/* ------------------------------------ */
/* Initialize system					*/
/* ------------------------------------ */
Hooks.once('init', async function () {
    console.log('Hellas | Initializing hellas');
    // Assign custom classes and constants here
    game.hellas = {
        HellasActor,
        HellasActorSheet,
        HellasItem,
        HellasSkillAbilityItem: HellasSkillItem,
        HellasWeaponItem: HellasWeaponItem,
        HellasArmorItem: HellasArmorItem,
        HellasDynamismItem: HellasDynamismItem,
        HellasTalentItem: HellasTalentItem
    };
    game.HELLAS = HELLAS;
    // define custom entity classes
    // @ts-ignore
    CONFIG.Actor.entityClass = HellasActor;
    // @ts-ignore
    CONFIG.Item.entityClass = HellasItem;
    // @ts-ignore
    Actors.unregisterSheet("core", ActorSheet);
    // @ts-ignore
    Actors.registerSheet(systemName, HellasActorSheet, { makeDefault: true });
    Items.unregisterSheet("core", ItemSheet);
    Items.registerSheet(systemName, HellasSkillItemSheet, { types: [HellasSkillItem.type], makeDefault: true, label: "Hellas Skill" });
    Items.registerSheet(systemName, HellasWeaponItemSheet, { types: [HellasWeaponItem.type], makeDefault: true, label: "Hellas Weapon" });
    Items.registerSheet(systemName, HellasArmorItemSheet, { types: [HellasArmorItem.type], makeDefault: true, label: "Hellas Armor" });
    Items.registerSheet(systemName, HellasDynamismItemSheet, { types: [HellasDynamismItem.type], makeDefault: true, label: "Hellas Dynamism" });
    Items.registerSheet(systemName, HellasTalentItemSheet, { types: [HellasTalentItem.type], makeDefault: true, label: "Hellas Talent" });
    // Register custom system settings
    registerSettings();
    // Preload Handlebars templates
    await preloadTemplates();
    // Register custom sheets (if any)
});
/* ------------------------------------ */
/* Setup system							*/
/* ------------------------------------ */
Hooks.once('setup', function () {
    // Do anything after initialization but before
    // ready
});
/* ------------------------------------ */
/* When ready							*/
/* ------------------------------------ */
Hooks.once('ready', function () {
    // Do anything once the system is ready
});
// Add any additional hooks if necessary
